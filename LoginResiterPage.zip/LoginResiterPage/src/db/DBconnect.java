/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package db;

/**
 *
 * @author HP
 */
import java.sql.*;
import javax.swing.JOptionPane;
public class DBconnect {
    
    public static Connection con;
    public static Statement s;
    
   static{
        
    try{
    con =DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system","infi");
    s=con.createStatement();
    
    }
    catch(SQLException e){
        JOptionPane.showMessageDialog(null, e);
    }}
}
